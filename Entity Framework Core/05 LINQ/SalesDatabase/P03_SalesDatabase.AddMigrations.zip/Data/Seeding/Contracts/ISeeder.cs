﻿namespace P03_SalesDatabase.Data.Seeding.Contracts
{
    public interface ISeeder
    {
        public void Seed();
    }
}
