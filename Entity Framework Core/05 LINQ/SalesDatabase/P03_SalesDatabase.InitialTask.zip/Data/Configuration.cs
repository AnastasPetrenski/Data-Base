﻿namespace P03_SalesDatabase.Data
{
    public class Configuration
    {
        public static string ConnectionString = "Server=.;Database=SalesDatabase;Integrated Security=true";
    }
}
