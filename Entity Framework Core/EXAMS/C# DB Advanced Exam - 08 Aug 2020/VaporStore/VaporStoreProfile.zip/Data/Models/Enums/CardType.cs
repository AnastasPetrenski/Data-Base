﻿namespace VaporStore.Data.Models.Enums
{
    public enum CardType
    {
        //TODO: Check if start by 0
        Debit = 1,
        Credit = 2
    }
}
