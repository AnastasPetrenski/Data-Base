﻿using ProductShop.Data;
using ProductShop.Dtos.Import;
using ProductShop.Models;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            ProductShopContext context = new ProductShopContext();

            //context.Database.EnsureDeleted();
            //context.Database.EnsureCreated();

            var relativePath = GetDirectoryPath();

            var inputXML = File.ReadAllText(relativePath);

            var result = ImportUsers(context, inputXML);
        }

        private static string GetDirectoryPath()
        {
            var currentDirectory = Directory.GetCurrentDirectory();
            var directories = Directory.GetDirectories(currentDirectory);

            return directories.Any(x => x.Contains("Datasets")) ? "/users.xml" : "../../../Datasets/users.xml";
        }

        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            var root = new XmlRootAttribute("Users");

            var serializer = new XmlSerializer(typeof(ImportUserDTO[]), root);

            var inportedUsers = serializer.Deserialize(new StringReader(inputXml)) as ImportUserDTO[];

            var result = inportedUsers
                            .Select(u => new User
                            {
                                FirstName = u.FirstName,
                                LastName = u.LastName,
                                Age = u.Age
                            })
                            .ToList();

            context.Users.AddRange(result);
            context.SaveChanges();

            return $"Successfully imported {result.Count}";
        }

        private static XmlSerializerNamespaces GetXmlNamespaces()
        {
            XmlSerializerNamespaces xmlNamespaces = new XmlSerializerNamespaces();
            xmlNamespaces.Add(string.Empty, string.Empty);
            return xmlNamespaces;
        }

        //var builder = new StringBuilder();
        //using var writer = new StringWriter(builder);
        //Stream stream = new MemoryStream();

        //    using (TextWriter text = new StreamWriter(stream, Encoding.UTF8))
        //    {
        //        serializer.Serialize(stream, writer);
        //    }
    }
}